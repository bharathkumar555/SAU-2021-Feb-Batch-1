export interface User {
    fName: string;
    lName : string;
    dob : string;
    age : number;
    username : string;
    email : string;
    password : string;
}