import { combineReducers } from 'redux'
import bookstore from './bookstore'

export default combineReducers({
  bookstore,
})