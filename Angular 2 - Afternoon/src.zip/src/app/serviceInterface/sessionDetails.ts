export interface SessionDetails {
    name: string;
    instructor : string;
    description : string;
}